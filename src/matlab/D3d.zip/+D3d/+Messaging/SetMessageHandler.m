function SetMessageHandler(msgFunctionPointer)
    global EXT_MESAGE_FUNC

    EXT_MESAGE_FUNC = msgFunctionPointer;
end
