function DeleteAll()
    D3d.Viewer.DeleteAllPolygons();
end
