% ResetView - ResetView() This will reset the camera to its default position and view.
function ResetView()
    D3d.Viewer.Mex('ResetView');
end
