% DeleteAllPolygons - DeleteAllPolygons() This will remove all of the polygons.
function DeleteAllPolygons()
    D3d.Viewer.Mex('DeleteAllPolygons');
end
