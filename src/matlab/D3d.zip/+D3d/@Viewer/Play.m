% Play - This will toggle the automatic playing of the movie.
%    Viewer.Play(playOn)
%    	PlayOn - This is a double that is either a zero or a one, where a zero indicates not playing and a one indicates playing.
function Play(playOn)
    D3d.Viewer.Mex('Play',playOn);
end
