% ShowWidget - This will toggle the Widget on and off.
%    Viewer.ShowWidget(on)
%    	On - If this is set to one, then the Widget will be on. If this is 0, the Widget will be off.
function ShowWidget(on)
    D3d.Viewer.Mex('ShowWidget',on);
end
