% Poll - MessageArray = Poll() 
function MessageArray = Poll()
    [MessageArray] = D3d.Viewer.Mex('Poll');
end
