% RemovePolygon - RemovePolygon(index) This removes all polygons from the directX viewer
function RemovePolygon(index)
    D3d.Viewer.Mex('RemovePolygon',index);
end
