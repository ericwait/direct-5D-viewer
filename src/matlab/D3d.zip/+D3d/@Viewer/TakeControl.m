% TakeControl - TakeControl() This will stop the renderer until the 'ReleaseControl' command is called.
function TakeControl()
    D3d.Viewer.Mex('TakeControl');
end
