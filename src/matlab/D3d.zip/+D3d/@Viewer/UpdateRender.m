% UpdateRender - UpdateRender() 	Forces the display to update.
function UpdateRender()
    D3d.Viewer.Mex('UpdateRender');
end
