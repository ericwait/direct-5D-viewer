% ReleaseControl - ReleaseControl() This will allow the renderer to start up again.
function ReleaseControl()
    D3d.Viewer.Mex('ReleaseControl');
end
