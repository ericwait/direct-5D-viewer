% ShowFrameNumber - This will toggle the FrameNumber on and off.
%    Viewer.ShowFrameNumber(on)
%    	On - If this is set to one, then the FrameNumber will be on. If this is 0, the FrameNumber will be off.
function ShowFrameNumber(on)
    D3d.Viewer.Mex('ShowFrameNumber',on);
end
