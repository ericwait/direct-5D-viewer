% Close - Close() Will close the DirectX viewer.
function Close()
    D3d.Viewer.Mex('Close');
end
