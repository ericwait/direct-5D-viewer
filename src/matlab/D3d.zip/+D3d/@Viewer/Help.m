% Help - Help on a specified command.
%    Viewer.Help(command)
%    Print detailed usage information for the specified command.
function Help(command)
    D3d.Viewer.Mex('Help',command);
end
