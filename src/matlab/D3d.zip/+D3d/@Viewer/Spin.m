% Spin - This will start the volume rotating about the view aligned y axis.
%    Viewer.Spin(on)
%    	On - If this is set to one, then the volume will rotate. If this is 0, the volume will not rotate.
function Spin(on)
    D3d.Viewer.Mex('Spin',on);
end
