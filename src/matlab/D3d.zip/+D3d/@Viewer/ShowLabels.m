% ShowLabels - This will toggle the polygon labels on and off.
%    Viewer.ShowLabels(on)
%    	On - If this is set to one, then all of the polygon labels will be on. If this is 0, all of the polygon labels will be off.
function ShowLabels(on)
    D3d.Viewer.Mex('ShowLabels',on);
end
