% ShowScaleBar - This will toggle the ScaleBar on and off.
%    Viewer.ShowScaleBar(on)
%    	On - If this is set to one, then the ScaleBar will be on. If this is 0, the ScaleBar will be off.
function ShowScaleBar(on)
    D3d.Viewer.Mex('ShowScaleBar',on);
end
