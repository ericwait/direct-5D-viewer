% CaptureSpinMovie - CaptureSpinMovie() This will capture 720 images with the current view spinning 0.5 degrees per frame
function CaptureSpinMovie()
    D3d.Viewer.Mex('CaptureSpinMovie');
end
