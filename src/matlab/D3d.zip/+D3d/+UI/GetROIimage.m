function [roiIm,roiData] = GetROIimage()
    global MipROIim MipROIimData
    
    roiIm = MipROIim;
    roiData = MipROIimData;
end